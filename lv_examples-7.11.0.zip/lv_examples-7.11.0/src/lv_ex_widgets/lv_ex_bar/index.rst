C
^
Simple Bar 
""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_bar/lv_ex_bar_1
  :language: c

MicroPython
^^^^^^^^^^^

.. lv_example:: lv_ex_widgets/lv_ex_bar/lv_ex_bar_1
  :language: py
