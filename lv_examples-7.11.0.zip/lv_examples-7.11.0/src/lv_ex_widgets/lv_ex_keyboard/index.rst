C
^

Keyboard with text area 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_keyboard/lv_ex_keyboard_1
  :language: c

MicroPython
^^^^^^^^^^^

Keyboard with text area
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_keyboard/lv_ex_keyboard_1
  :language: py
