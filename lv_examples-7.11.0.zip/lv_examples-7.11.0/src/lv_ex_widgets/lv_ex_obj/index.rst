C
^

Base objects with custom styles 
""""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_obj/lv_ex_obj_1
  :language: c

MicroPython
^^^^^^^^^^^

Base objects with custom styles 
""""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_obj/lv_ex_obj_1
  :language: py
